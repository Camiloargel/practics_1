# Práctica I — De los píxeles a la integral: área bajo una curva

**Curso:** ST0244 - Programming Languages Programming
**Profesor:** Alexander Narváez Berrío
**Paradigmas:** Programación funcional (Haskell) · Programación lógica (Prolog)

## Integrantes del equipo

- Nombre 1 — usuario GitHub
- Nombre 2 — usuario GitHub
- Nombre 3 — usuario GitHub

*(completar con los datos reales del equipo antes de subir el repositorio)*

## Entorno de desarrollo

- **Sistema operativo:** Ubuntu 24.04 (Linux)
- **Haskell:** GHC 9.4.7 (`ghc`), sin dependencias externas más allá de las librerías base (`bytestring`, `text`, etc.)
- **Prolog:** SWI-Prolog 9.0.4, sin librerías externas

## Estructura del repositorio

```
.
├── README.md
├── curva_binaria_P4.pbm      # imagen binaria suministrada por el profesor
├── Haskell/
│   └── Main.hs                # solución funcional
└── Prolog/
    └── main.pl                # solución declarativa
```

## Cómo ejecutar la solución en Haskell

Desde la carpeta `Haskell/`:

```bash
ghc -O2 -o main Main.hs
./main ../curva_binaria_P4.pbm
```

También se puede ejecutar directamente sin compilar, con `runghc`:

```bash
runghc Main.hs ../curva_binaria_P4.pbm
```

Si no se pasa ruta como argumento, el programa asume por defecto
`../curva_binaria_P4.pbm`.

## Cómo ejecutar la solución en Prolog

Desde la carpeta `Prolog/`:

```bash
swipl main.pl ../curva_binaria_P4.pbm
```

El predicado `main/1` se ejecuta automáticamente al cargar el archivo
(`:- initialization(main, main).`) y recibe la ruta del `.pbm` como
argumento de línea de comandos. Si no se pasa ninguna ruta, usa por
defecto `../curva_binaria_P4.pbm`.

## Área obtenida

Ambos programas, ejecutados sobre `curva_binaria_P4.pbm` (imagen de
**567 × 319** píxeles), calculan exactamente la misma área:

```
Área = 108660 píxeles cuadrados
```

Este valor coincide con el que produce la implementación de referencia
en C++ suministrada por el profesor, lo cual confirma que ambos
paradigmas llegan al mismo resultado matemático a pesar de expresarlo
de formas completamente distintas.

## Estrategia para mostrar la imagen en la consola

La imagen original (567 × 319 píxeles) es mucho más grande que una
terminal típica, así que ambos programas usan la misma estrategia de
**muestreo espacial (nearest-neighbor sampling)**:

1. Se decide un tamaño de salida fijo para la consola, por ejemplo
   **90 columnas × 30 filas** de caracteres.
2. Para cada carácter `(c, fila)` de esa cuadrícula, se calcula a qué
   píxel `(x, y)` de la imagen original le corresponde
   proporcionalmente:

   ```
   x = (c    * ancho) div columnas_deseadas
   y = (fila * alto)  div filas_deseadas
   ```

3. Se consulta ese único píxel de la imagen original y se imprime
   `#` si es negro o `.` si es blanco.

De esta manera no es necesario recorrer ni imprimir cada uno de los
más de 180 000 píxeles de la imagen: se toma una muestra representativa
que preserva la forma general de la curva.

Para la **función de alturas M[x] = f(x)** se usa una estrategia
análoga, pero en lugar de mostrar únicamente `#`/`.`, cada columna
muestreada se dibuja como una barra vertical construida con
caracteres de bloque Unicode (`▁▂▃▄▅▆▇█`), escalada según la altura
máxima observada en `M`. Esto permite ver, en un espacio reducido de
consola, cómo varía `f(x)` a lo largo de todo el dominio.

## `f(x)`, `M` y el área en cada paradigma

En ambas soluciones la relación matemática

```
A = Σ f(xᵢ) · Δx ,  con Δx = 1
```

es explícita, pero se expresa con un estilo distinto:

### Haskell — transformaciones sobre datos

```haskell
m    = map f [0 .. ancho - 1]   -- M = aplicar f a todo el dominio
area = sum m                     -- suma de Riemann
```

`M` nace de **aplicar** la función `f` a cada elemento del dominio
mediante `map`; el área nace de **acumular** esa lista con `sum`. El
énfasis está en la transformación: `dominio -> alturas -> área`.

### Prolog — relaciones que deben cumplirse

```prolog
alturas(Datos, Ancho, Alto, BytesPorFila, M) :-
    MaxX is Ancho - 1,
    findall(Altura,
            ( between(0, MaxX, X),
              f(X, Datos, Alto, BytesPorFila, Altura) ),
            M).

area(M, Area) :- sum_list(M, Area).
```

Aquí `f/5` es una **relación** entre una columna `X` y su altura
`Altura` (no un procedimiento). `M` es la colección de *todos los
valores que satisfacen esa relación* para `X` entre `0` y `Ancho-1`,
obtenida declarativamente con `findall/3`. El énfasis está en
describir *qué relación debe cumplirse*, no en los pasos para
calcularla: `relaciones -> valores que satisfacen f(x) -> M -> área`.

## Notas de implementación

- Ninguno de los dos programas convierte manualmente el `.pbm` a una
  matriz de texto: ambos leen el archivo binario directamente y
  acceden a los bits con aritmética de bytes/bits (`x div 8`,
  `7 - x mod 8`).
- El acceso a píxeles respeta el formato PBM P4: cada fila ocupa
  `ceil(ancho / 8)` bytes y un bit en `1` representa la región bajo la
  curva (negro).
- `f(x)` cuenta píxeles negros consecutivos desde el fondo de la
  imagen (`y = alto - 1`) hacia arriba, deteniéndose en el primer
  píxel blanco — en Haskell con `takeWhile`, en Prolog con una
  relación recursiva (`altura_desde/6`).
